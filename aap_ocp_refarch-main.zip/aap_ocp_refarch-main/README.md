# Deploying Ansible Automation Platform 2 on Red Hat OpenShift

The files found within this repository are supplemental to the Deploying Ansible Automation Platform 2 on Red Hat OpenShift Reference Architecture. 

For questions, feedback or concerns send mail to: ansible-feedback@redhat.com
